#ifndef _array_Management_
#define _array_Management_
void sortingArray(char palabraOrdenada[], unsigned int indices[], char letras[], unsigned int length);
void dumpArray(char a[], unsigned int length);
#endif