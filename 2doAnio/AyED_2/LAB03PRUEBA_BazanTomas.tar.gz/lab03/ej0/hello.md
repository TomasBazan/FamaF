

this is not a program, I learn how to use vim
j and k for down and up
h and l for left and right









hjkl