#include <stdio.h>
#include <stdlib.h>
#include "array_helpers.h"
#include "weather_utils.h"

int minTempHis(WeatherTable array)
{
    int minTemp = array[0][0][0]._max_temp;
    for (unsigned int year = 0u; year < YEARS; year++)
    {
        for (unsigned int month = january; month <= december; month++)
        {
            for (unsigned int day = 0u; day < DAYS; day++)
            {
                if (minTemp > array[year][month][day]._min_temp)
                {
                    minTemp = array[year][month][day]._min_temp;
                }
            }
        }
    }
    return minTemp;
}

