#ifndef _WEATHER_UTILS_
#define _WEATHER_UTILS_


int minTempHis(WeatherTable array);
//void maxTempAnio(WeatherTable array);
#endif