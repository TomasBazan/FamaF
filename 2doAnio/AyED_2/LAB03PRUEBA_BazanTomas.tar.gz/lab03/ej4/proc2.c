#include <stdlib.h>
#include <stdio.h>

void absolute(int x, int *y) {
    // Completar aqui
}

int main(void) {
    // Completar aqui
    return EXIT_SUCCESS;
}

