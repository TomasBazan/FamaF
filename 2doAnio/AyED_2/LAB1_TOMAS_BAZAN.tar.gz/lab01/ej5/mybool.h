#ifndef _myBool_
#define _myBool_
#define true 1
#define false 0

typedef int mybool;
#endif