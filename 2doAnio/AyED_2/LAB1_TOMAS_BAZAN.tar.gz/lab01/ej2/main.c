/* First, the standard lib includes, alphabetically ordered */
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

/* Maximum allowed length of the array */
#define MAX_SIZE 100000

unsigned int array_from_file(int array[],
                             unsigned int max_size)
{
    unsigned int i = 0;
    //para que no me moleste
    unsigned int length = max_size;
    FILE *f;
    f = stdin;

    fprintf(stdout, "Ingrese el tamanio del arreglo \n");
    fscanf(f, "%u", &length);
    fprintf(stdout, "Ingrese los numeros del arreglo \n");

    while (i < length)
    {
        fscanf(f, "%d", &array[i]);
        i++;
    }
    return length;
}


void array_dump(int a[], unsigned int length)
{
    if (length == 0)
    {
        printf("[]\n");
    }
    else
    {
        printf("[ ");
        for (unsigned int i = 0; i < length; i++)
        {
            if (i == length - 1)
            {
                printf(" %d ] \n", a[i]);
            }
            else
            {
                printf(" %d,", a[i]);
            }
        }
    }
}

int main()
{
    /* create an array of MAX_SIZE elements */
    int array[MAX_SIZE];

    /* parse the file to fill the array and obtain the actual length */
    unsigned int length = array_from_file(array, MAX_SIZE);

    /*dumping the array*/
    array_dump(array, length);

    return EXIT_SUCCESS;
}
